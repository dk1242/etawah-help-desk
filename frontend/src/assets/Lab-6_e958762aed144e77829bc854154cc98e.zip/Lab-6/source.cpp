/*
 * source.cpp
 *
 *  Created on: Apr 10, 2019
 *      Author: dell
 */

#include<iostream>
#include<stdlib.h>
using namespace std;

// Number of processes
const int numP = 5;
// Number of resources
const int numR = 3;
// Max resource allocation to each process
int maxAlloc[][numR] = {{ 7, 5, 3 }, { 3, 2, 2 }, { 9, 0, 2 }, { 2, 2,	2 }, { 4, 3, 3 }};

// Calculate the resource need for a process
void calcNeed(int need[][numR], int allot[][numR])
{
	// Calculating Need of each Process
	for (int i = 0; i < numP; i++)
		for (int j = 0; j < numR; j++)
			// Need of instance = maxm instance - allocated instance
			need[i][j] = maxAlloc[i][j] - allot[i][j];
}

// Function to find the system is in safe state or not
void isSafe(int processes[], int avail[], int allot[][numR], int need[][numR])
{
	// To be completed
}

// Function to check if given resource request can be processed.
void processReq(int proID, int req[], int avail[], int allot[][numR], int need[][numR])
{
	// To be completed
}


// Driver code
int main()
{
    int processes[] = {0, 1, 2, 3, 4};
	// Resources allocated to processes
    int allot[][numR] = {{0, 1, 0},{2, 0, 0},{3, 0, 2},{2, 1, 1},{0, 0, 2}};
	cout << "System information at time - T0" << endl;
	cout << "Maximum allocation to different processes " << endl;
	for(int i = 0; i < numP; i++)
	{
		for(int j = 0; j < numR; j++)
			cout << maxAlloc[i][j] << " ";
		cout << endl;
	}
    // Available instances of resources
    int avail[] = {3, 3, 2};
	cout << "Available resouces instances at time - T0" << endl;
	for(int j = 0; j < numR; j++)
		cout << avail[j] << " ";
	cout << endl;
	cout << "Allocation to different processes at - T0 " << endl;
	for(int i = 0; i < numP; i++)
	{
		for(int j = 0; j < numR; j++)
			cout << allot[i][j] << " ";
		cout << endl;
	}
	// Computer system need
    int procNeed[numP][numR];
	calcNeed(procNeed, allot);
    // Check system is in safe state or not
    isSafe(processes, avail, allot, procNeed);
    int pID = 4;
    int req[numR] = {3, 3, 0};
//    cout << "New resource request - Enter process id" << endl;
//    cin >> pID;
//    cout << "Enter instance request " << endl;
//    for(int i = 0; i < numR; i++)
//    	cin >> req[i];
    processReq(pID, req, avail, allot, procNeed);
    // Check system is in safe state or not
    isSafe(processes, avail, allot, procNeed);
    return 0;
}
